import express from "express";
import {
  getEmployees,
  getOneEmployee,
  addEmployee,
  updateEmployee,
  deleteEmployee,
} from "../controllers/employeeControllers";
const router = express.Router();

router.get("/all-employees", getEmployees as any);
router.get("/:id", getOneEmployee as any);
router.post("/create-employee", addEmployee as any);
router.patch("/update-employee/:id", updateEmployee as any);
router.delete("/delete-employee/:id", deleteEmployee as any);

export default router;
