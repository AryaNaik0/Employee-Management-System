import mongoose from "mongoose";

interface Employee extends Document {
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone?: string;
  dateOfBirth?: Date;
  isActive: boolean;
  fullName: string;
}

const empSchema = new mongoose.Schema<Employee>(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      validate: {
        validator: (email: string) => {
          return /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email); 
        },
        message: "Please enter a valid email",
      },
    },
    department: {
      type: String,
      required: true,
      enum: ["HR", "Engineering", "Sales", "Marketing", "Support"], 
    },
    role: {
      type: String,
      required: true,
      enum: ["Admin", "Manager", "Staff"], 
    },
    street: {
      type: String,
      required: true,
    },
    city: {
      type: String,
      required: true,
    },
    state: {
      type: String,
      required: true,
    },
    zipCode: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      validate: {
        validator: (phone: string) => {
          return /^\d{10}$/.test(phone); 
        },
        message: "Please enter a valid 10-digit phone number",
      },
    },
    dateOfBirth: {
      type: Date,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

const Employee = mongoose.model("Employee", empSchema);

export default Employee;
