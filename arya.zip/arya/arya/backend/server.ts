import express, { Request, Response } from "express";
import cors from "cors";
import corsConfig from "./config/corsConfig";
import { config } from "dotenv";
import connectDb from "./config/db";
import mongoose from "mongoose";
import errorHandler from "./middlewares/errorHandler";
import empRoutes from "./routes/empRoutes";

const app = express();
config();
connectDb(process.env.DATABASE_URL!);

app.use(cors(corsConfig));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//employee CRUD routes
app.use("/api/employees", empRoutes);
app.use(errorHandler);
mongoose.connection.once("open", () => {
  app.listen(3000, () => {
    console.log("server started on port 3000");
  });
});
