import mongoose, { MongooseError } from "mongoose";

const connectDb = async (url: string) => {
  try {
    await mongoose.connect(url);
    console.log("successfully connected to db");
  } catch (error) {
    if (error instanceof MongooseError) throw new Error(error.message);
    throw new Error("Failed to connect to database");
  }
};

export default connectDb;
