import express from "express";
import Employee from "../models/Employee";
import mongoose from "mongoose";

interface Body {
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone?: string;
  dateOfBirth?: Date;
  isActive?: boolean;
}

export const getEmployees = async (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) => {
  try {
    const allEmployees = await Employee.aggregate<Employee>([
      { $match: { isActive: true } },
    ]);
    if (!allEmployees?.length) {
      return res.status(404).json({ message: "No employees available" });
    }

    res.status(200).json({ allEmployees });
  } catch (error) {
    next(error);
  }
};

export const getOneEmployee = async (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid ID" });
    }

    const employee = await Employee.findOne({ _id: id }).lean().exec();
    if (!employee)
      return res.status(404).json({ message: "No such employee found" });

    res.status(200).json(employee);
  } catch (error) {
    next(error);
  }
};

export const addEmployee = async (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) => {
  try {
    const {
      firstName,
      lastName,
      email,
      department,
      role,
      street,
      city,
      state,
      zipCode,
      phone,
      dateOfBirth,
    } = req.body as Body;

    if (!firstName || !lastName || !email || !department || !role) {
      return res.status(400).json({
        message:
          "First name, last name, email, department, and role are required.",
      });
    }

    const newEmployee = new Employee({
      firstName,
      lastName,
      email,
      department,
      role,
      street,
      city,
      state,
      zipCode,
      phone,
      dateOfBirth,
    });

    await newEmployee.save();

    res
      .status(201)
      .json({ message: "Employee added successfully", employee: newEmployee });
  } catch (error) {
    next(error);
  }
};

export const updateEmployee = async (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) => {
  try {
    const { id } = req.params;
    const {
      firstName,
      lastName,
      role,
      street,
      city,
      state,
      zipCode,
      phone,
      department,
      isActive,
      dateOfBirth,
    } = req.body as Partial<Body>;

    const updatedEmployee = await Employee.findByIdAndUpdate(
      id,
      {
        firstName,
        lastName,
        role,
        street,
        city,
        state,
        zipCode,
        phone,
        department,
        isActive,
        dateOfBirth,
      },
      { new: true, runValidators: true }
    )
      .lean()
      .exec();

    if (!updatedEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    res.status(200).json({
      message: "Employee updated successfully",
      employee: updatedEmployee,
    });
  } catch (error) {
    next(error);
  }
};

export const deleteEmployee = async (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid ID" });
    }

    const employee = await Employee.findById(id).lean().exec();
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const deletedEmployee = await Employee.findOneAndUpdate(
      { _id: id },
      { isActive: false },
      { new: true }
    )
      .lean()
      .exec();
    if (!deletedEmployee) {
      return res.status(400).json({ message: "Could not delete employee" });
    }

    res.status(200).json({ message: "Successfully deleted employee" });
  } catch (error) {
    next(error);
  }
};
