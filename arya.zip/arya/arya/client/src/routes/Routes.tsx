import MainLayout from "@/layouts/MainLayout";
import Home from "@/pages/Home";
import NewEmployee from "@/pages/NewEmployee";
import UpdateEmployee from "@/pages/UpdateEmployee";
import { createBrowserRouter } from "react-router-dom";

const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: "new-employee",
        element: <NewEmployee />,
      },
      {
        path: "update-employee/:id",
        element: <UpdateEmployee />,
      },
    ],
  },
]);

export default router;
