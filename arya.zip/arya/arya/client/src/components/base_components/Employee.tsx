import { UseMutateFunction } from "@tanstack/react-query";
import { Button } from "../ui/button";
import { useNavigate } from "react-router-dom";

type Employee = {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  department: "HR" | "Engineering" | "Sales" | "Marketing" | "Support";
  role: "Admin" | "Manager" | "Staff";
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone?: string;
  dateOfBirth?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
};

interface EmployeeCardProps {
  employee: Employee;
  mutate: UseMutateFunction<void, Error, string, unknown>;
}

export default function EmployeeCard({ employee, mutate }: EmployeeCardProps) {
  const navigate = useNavigate();
  return (
    <div className="max-w-sm mx-auto bg-[#A4BAB7] p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-2 text-[#EFF2C0]">
        {employee.firstName} {employee.lastName}
      </h2>
      <p className="text-gray-700 mb-2">
        <strong>Email:</strong> {employee.email}
      </p>
      <p className="text-gray-700 mb-2">
        <strong>Department:</strong> {employee.department}
      </p>
      <p className="text-gray-700 mb-2">
        <strong>Role:</strong> {employee.role}
      </p>

      <div className="flex items-end justify-end gap-4">
        <Button
          onClick={() => navigate(`/update-employee/${employee._id}`)}
          className="bg-green-600 text-white hover:bg-green-700"
        >
          Edit
        </Button>
        <Button
          onClick={() => mutate(employee._id)}
          className="bg-red-600 text-white hover:bg-red-700"
        >
          Delete
        </Button>
      </div>
    </div>
  );
}
