import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ChangeEvent, FormEvent, useEffect, useState } from "react";
import { UseMutateFunction } from "@tanstack/react-query";

type Data = {
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  dateOfBirth: string;
};

type Props = {
  onSubmit: UseMutateFunction<void, Error, Partial<Data>, unknown>;
  initialData?: Partial<Data>;
};

export default function Form({ onSubmit, initialData = {} }: Props) {
  const [formData, setFormData] = useState<Data>({
    firstName: "",
    lastName: "",
    email: "",
    department: "",
    role: "",
    street: "",
    city: "",
    state: "",
    zipCode: "",
    phone: "",
    dateOfBirth: "",
    ...initialData, // Initial data for form prefill
  });

  useEffect(() => {
    setFormData((prev) => ({ ...prev, ...initialData }));
  }, [initialData]);

  const handleChange = (
    e: ChangeEvent<HTMLInputElement> | string,
    selectName?: string
  ) => {
    if (typeof e === "string" && selectName) {
      setFormData((prev) => ({ ...prev, [selectName]: e }));
    } else if (typeof e !== "string" && e.target) {
      const { name, value } = e.target;
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-gray-800 text-white p-8 shadow-lg rounded-lg max-w-2xl mx-auto"
    >
      <h2 className="text-2xl font-semibold text-center mb-6">
        Employee Information
      </h2>
      <p className="text-gray-400 text-center mb-8">
        Please fill out the information below to update employee details.
      </p>

      <div className="grid gap-4 sm:grid-cols-2 mb-6">
        <div className="space-y-2">
          <Label htmlFor="firstName">First Name</Label>
          <Input
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Last Name</Label>
          <Input
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Phone</Label>
          <Input
            id="phone"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="dateOfBirth">Date of Birth</Label>
          <Input
            id="dateOfBirth"
            name="dateOfBirth"
            type="date"
            value={formData.dateOfBirth}
            onChange={handleChange}
          />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 mb-6">
        <div className="space-y-2">
          <Label htmlFor="department">Department</Label>
          <Select
            name="department"
            value={formData.department}
            onValueChange={(value) => handleChange(value, "department")}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="HR">HR</SelectItem>
              <SelectItem value="Engineering">Engineering</SelectItem>
              <SelectItem value="Sales">Sales</SelectItem>
              <SelectItem value="Marketing">Marketing</SelectItem>
              <SelectItem value="Support">Support</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="role">Role</Label>
          <Select
            name="role"
            value={formData.role}
            onValueChange={(value) => handleChange(value, "role")}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Admin">Admin</SelectItem>
              <SelectItem value="Manager">Manager</SelectItem>
              <SelectItem value="Staff">Staff</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <h3 className="text-xl font-medium mb-4">Address Information</h3>
      <div className="grid gap-4 sm:grid-cols-2 mb-6">
        <div className="space-y-2">
          <Label htmlFor="street">Street</Label>
          <Input
            id="street"
            name="street"
            value={formData.street}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="city">City</Label>
          <Input
            id="city"
            name="city"
            value={formData.city}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="state">State</Label>
          <Input
            id="state"
            name="state"
            value={formData.state}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="zipCode">Zip Code</Label>
          <Input
            id="zipCode"
            name="zipCode"
            value={formData.zipCode}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <Button
        type="submit"
        className="w-full bg-green-500 text-white hover:bg-green-600 transition duration-300 py-2 font-semibold rounded-lg"
      >
        Submit
      </Button>
    </form>
  );
}
