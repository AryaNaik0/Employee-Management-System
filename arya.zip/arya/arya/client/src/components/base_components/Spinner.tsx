export default function Spinner() {
  return (
    <span className="loader inline-block w-12 h-12 border-4 border-white border-b-transparent rounded-full animate-spin"></span>
  );
}
