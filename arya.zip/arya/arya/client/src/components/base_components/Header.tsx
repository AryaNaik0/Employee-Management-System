import { Button } from "../ui/button";
import { PlusIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Header() {
  const navigate = useNavigate();
  return (
    <header className="flex items-center justify-between p-6 bg-gradient-to-r from-gray-800 to-gray-700 shadow-md">
      <h1 className="text-2xl sm:text-3xl font-semibold text-[#EFF2C0] tracking-wide">
        Employee Management
      </h1>
      <Button
        onClick={() => navigate("/new-employee")}
        className="flex items-center space-x-2 px-4 py-2 bg-[#4CAF50] hover:bg-[#45a049] transition duration-300 text-white rounded-md shadow-sm"
      >
        <PlusIcon className="h-5 w-5" />
        <span>Add New Employee</span>
      </Button>
    </header>
  );
}
