import Form from "@/components/base_components/Form";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

type Data = {
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  dateOfBirth: string;
};

export default function UpdateEmployee() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { data, isLoading, error } = useQuery<Data>({
    queryKey: ["employee", id],
    queryFn: async () => {
      const response = await fetch(`http://localhost:3000/api/employees/${id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch employee data");
      }
      return response.json();
    },
  });

  const updateEmployeeMutation = useMutation({
    mutationFn: async (updatedData: Partial<Data>) => {
      const response = await fetch(
        `http://localhost:3000/api/employees/update-employee/${id}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedData),
        }
      );
      if (!response.ok) {
        throw new Error("Failed to update employee data");
      }
    },
    onSuccess: function () {
      toast.success("Successfully updated employee");
      navigate("/");
    },
    onError: function ({ message }) {
      toast.error(message);
    },
  });

  const handleFormSubmit = (updatedData: Partial<Data>) => {
    updateEmployeeMutation.mutate(updatedData);
  };

  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Error loading employee data</p>;

  return (
    <main className="min-h-screen bg-[#080F0F] p-8">
      <Form onSubmit={handleFormSubmit} initialData={data} />
    </main>
  );
}
