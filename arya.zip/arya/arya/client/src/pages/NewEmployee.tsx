import Form from "@/components/base_components/Form";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

type Data = {
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  role: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  dateOfBirth: string;
};

export default function NewEmployee() {
  const navigate = useNavigate();
  const { mutate } = useMutation({
    mutationFn: async function (data: Partial<Data>) {
      await fetch("http://localhost:3000/api/employees/create-employee", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
    },
    onSuccess: function () {
      toast.success("Successfully added new employee");
      navigate("/");
    },
    onError: function () {
      toast.error("Failed to add new Employee");
    },
  });
  return (
    <main className="min-h-screen bg-[#080F0F] p-8">
      <h1 className="text-center text-4xl">Add new Employee</h1>
      <Form onSubmit={mutate} />
    </main>
  );
}
