import Spinner from "../components/base_components/Spinner";
import EmployeeCard from "../components/base_components/Employee";
import { useQuery, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { queryClient } from "../main";

type Employee = {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  department: "HR" | "Engineering" | "Sales" | "Marketing" | "Support";
  role: "Admin" | "Manager" | "Staff";
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone?: string;
  dateOfBirth?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
};

export default function Home() {
  const { isLoading, data, error } = useQuery({
    queryFn: async function () {
      const response = await fetch(
        "http://localhost:3000/api/employees/all-employees"
      );
      if (response.status === 404) {
        return [];
      }
      if (!response.ok) {
        throw new Error("Failed to fetch employees");
      }
      const data = await response.json();
      return data.allEmployees;
    },
    queryKey: ["employees"],
  });

  const { mutate } = useMutation({
    mutationFn: async function (id: string) {
      await fetch(`http://localhost:3000/api/employees/delete-employee/${id}`, {
        method: "DELETE",
      });
    },
    mutationKey: ["employees"],
    onSuccess: function () {
      toast.success("Employee deleted successfully");
      queryClient.invalidateQueries();
    },
    onError: function () {
      toast.error("Something went wrong. Please try again.");
    },
  });

  let content;

  if (isLoading) {
    content = (
      <div className="flex justify-center items-center mt-8">
        <Spinner />
        <p className="text-gray-400 ml-4">Loading employees...</p>
      </div>
    );
  } else if (data && data.length > 0) {
    content = (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-8">
        {data.map((employee: Employee) => (
          <EmployeeCard
            key={employee._id}
            employee={employee}
            mutate={mutate}
          />
        ))}
      </div>
    );
  } else if (error) {
    content = (
      <p className="text-red-500 text-center mt-4">
        Error: {error.message}. Please refresh the page.
      </p>
    );
  } else if (data && !data.length) {
    content = (
      <p className="text-gray-400 text-center mt-8">
        No employees found. Add some to get started!
      </p>
    );
  }

  return (
    <main className="min-h-screen bg-[#080F0F] p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-semibold text-white text-center mb-4">
          Employee Directory
        </h1>
        {content}
      </div>
    </main>
  );
}
